# Step to avoid initial delay for choco scripts
choco upgrade chocolatey