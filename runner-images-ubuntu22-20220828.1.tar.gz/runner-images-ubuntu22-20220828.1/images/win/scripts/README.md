Common scripts for all Windows images regardless of Visual Studio or OS version
